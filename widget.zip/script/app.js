'use strict';
/**
 * @ngdoc overview
 * @name nahuobang
 * @description
 * # nahuobang
 *
 * Main module of the application.
 */
angular.module('app', ['vedioCtrl'])
    .config(['$compileProvider', function($compileProvider) {
        // http 安全配置白名单
        $compileProvider.aHrefSanitizationWhitelist(/^\s*(itms-services?|http|https|unsafe|ftp|mailto|chrome-extension):/);
        // Angular before v1.2 uses $compileProvider.urlSanitizationWhitelist(...)
    }])
 .run(['$rootScope', function ($rootScope) {
// /*       // 配置默认项 token user 等
           $rootScope.token = $rootScope.token || '';
        $rootScope.debug = false;


    		U.setStorage('api_url',"http://ys.rq5.top/");
        U.setStorage('ApiInterfaceUrl',"http://ys.rq5.top/app/api/");
    // localStorage.setItem('search_api_url',"http://ys.rq5.top/index.php/vod/search/wd/");//搜索接口
       $rootScope.urlPrefix = 'http://ys.rq5.top/app/api/';
        $rootScope.encodeType = 'multipart/form-data';
        $rootScope.contentType = 'application/x-www-form-urlencoded';
        $rootScope.limit = 10;
        $('[ng-app="app"]').css({opacity: 1});

    }


	]);
