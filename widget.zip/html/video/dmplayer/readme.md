# 功能描述

   h5弹幕视频播放器

# 依赖的模块
    ik2021.com
    

# 快速使用
导入包
	api.openFrame({
		name: 'dmplayer',
		url: 'dmplayer.html',//文件路径
		bounces: false,
		reload:true,
		rect: {
			x: 0,
			y: 20,
			w: 'auto',
			h: 260//位置自定义
		},

		pageParam:{play_url:url,play_title:"测试播放",play_sid:'1'}
	}) 
#可传参数
play_url：视频地址，必传
play_title：视频标题
play_sid：第几集
play_pic：播放器封面图片
# 特别说明

    